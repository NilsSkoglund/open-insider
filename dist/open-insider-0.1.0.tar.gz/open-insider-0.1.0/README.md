# Medium multiply
A small demo library for a Medium publication about publishing libraries.

### Installation
```
pip install open_insider
```